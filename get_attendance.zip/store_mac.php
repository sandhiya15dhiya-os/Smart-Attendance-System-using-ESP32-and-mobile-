<?php
require_once 'config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$mac_address = $_POST['mac_address'] ?? '';
$date = date('Y-m-d'); // Current date

if (!$mac_address) {
    http_response_code(400);
    echo json_encode(['error' => 'MAC address required']);
    exit;
}

// Check if the date is a holiday or Sunday
$sql = "SELECT status, description FROM holidays WHERE date = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $date);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $holiday = $result->fetch_assoc();
    if ($holiday['status'] === 'Holiday' || $holiday['description'] === 'Sunday') {
        echo json_encode(['error' => 'Cannot mark attendance on a holiday or Sunday']);
        $stmt->close();
        exit;
    }
}
$stmt->close();

// Check if MAC address exists in students table
$sql = "SELECT id FROM students WHERE mac_address = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $mac_address);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['error' => 'MAC address not found in students']);
    $stmt->close();
    exit;
}
$student = $result->fetch_assoc();
$student_id = $student['id'];
$stmt->close();

// Insert or update attendance
$sql = "INSERT INTO attendance (student_id, date, status, mac_address) VALUES (?, ?, 'Present', ?) 
        ON DUPLICATE KEY UPDATE status = 'Present', mac_address = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('isss', $student_id, $date, $mac_address, $mac_address);

if ($stmt->execute()) {
    echo json_encode(['status' => 'Success']);
} else {
    echo json_encode(['error' => 'Failed to store attendance']);
}

$stmt->close();
$conn->close();
?>