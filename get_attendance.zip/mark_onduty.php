<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

$roll_no = $_POST['student_id'] ?? '';
$date = $_POST['date'] ?? '';

if (!$roll_no || !$date) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing parameters']);
    exit;
}

$roll_no = $conn->real_escape_string($roll_no);
$date = $conn->real_escape_string($date);

// Check if the date is a holiday or Sunday
$sql_holiday = "SELECT status, description FROM holidays WHERE date = ?";
$stmt_holiday = $conn->prepare($sql_holiday);
$stmt_holiday->bind_param('s', $date);
$stmt_holiday->execute();
$result_holiday = $stmt_holiday->get_result();
if ($result_holiday->num_rows > 0) {
    $holiday = $result_holiday->fetch_assoc();
    if ($holiday['status'] === 'Holiday' || $holiday['description'] === 'Sunday') {
        echo json_encode(['error' => 'Cannot mark On Duty on a holiday or Sunday']);
        $stmt_holiday->close();
        $conn->close();
        exit;
    }
}
$stmt_holiday->close();

// Check if attendance record exists
$checkSql = "SELECT a.id FROM attendance a
                JOIN students s ON a.student_id = s.id
                WHERE s.roll_no = ? AND a.date = ?";
$stmt_check = $conn->prepare($checkSql);
$stmt_check->bind_param('ss', $roll_no, $date);
$stmt_check->execute();
$result = $stmt_check->get_result();

if ($result->num_rows === 0) {
    // Insert if not exists
    $insertSql = "INSERT INTO attendance (student_id, date, status)
                SELECT id, ?, 'On Duty' FROM students
                WHERE roll_no = ?";
    $stmt_insert = $conn->prepare($insertSql);
    $stmt_insert->bind_param('ss', $date, $roll_no);
    $success = $stmt_insert->execute();
    $stmt_insert->close();
} else {
    // Update if already exists
    $updateSql = "UPDATE attendance a
                JOIN students s ON a.student_id = s.id
                SET a.status = 'On Duty'
                WHERE s.roll_no = ? AND a.date = ?";
    $stmt_update = $conn->prepare($updateSql);
    $stmt_update->bind_param('ss', $roll_no, $date);
    $success = $stmt_update->execute();
    $stmt_update->close();
}

$stmt_check->close();

if ($success) {
    echo json_encode(['status' => 'Success']);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Update failed']);
}

$conn->close();
?>