<?php
session_start();
require_once 'config.php';

// Log to file for debugging
$logFile = 'summary_log.txt';
file_put_contents($logFile, date('[Y-m-d H:i:s] ') . "Processing request for roll_no: {$_GET['roll_no']}, month: {$_GET['month']}\n", FILE_APPEND);

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    file_put_contents($logFile, "Unauthorized access\n", FILE_APPEND);
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Establish database connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    file_put_contents($logFile, "Database connection failed: " . $conn->connect_error . "\n", FILE_APPEND);
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

file_put_contents($logFile, "Database connected successfully\n", FILE_APPEND);

// Get and sanitize inputs
$roll_no = $_GET['roll_no'] ?? '';
$month = $_GET['month'] ?? ''; // Expected format: YYYY-MM (e.g., 2025-08)

if (empty($roll_no) || empty($month)) {
    file_put_contents($logFile, "Missing roll_no or month\n", FILE_APPEND);
    http_response_code(400);
    echo json_encode(['error' => 'Roll number and month are required']);
    exit;
}

$roll_no = $conn->real_escape_string(trim($roll_no));
$month = $conn->real_escape_string(trim($month));

file_put_contents($logFile, "Sanitized inputs: roll_no=$roll_no, month=$month\n", FILE_APPEND);

// Validate month format (YYYY-MM)
if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
    file_put_contents($logFile, "Invalid month format\n", FILE_APPEND);
    http_response_code(400);
    echo json_encode(['error' => 'Invalid month format. Use YYYY-MM']);
    exit;
}

// Check if student exists
$sql_check = "SELECT id, name FROM students WHERE roll_no = ?";
$stmt_check = $conn->prepare($sql_check);
if ($stmt_check === false) {
    file_put_contents($logFile, "Student check query preparation failed: " . $conn->error . "\n", FILE_APPEND);
    http_response_code(500);
    echo json_encode(['error' => 'Student check query preparation failed: ' . $conn->error]);
    $conn->close();
    exit;
}

$stmt_check->bind_param('s', $roll_no);
$stmt_check->execute();
$result_check = $stmt_check->get_result();
if ($result_check->num_rows === 0) {
    file_put_contents($logFile, "No student found with roll_no: $roll_no\n", FILE_APPEND);
    http_response_code(404);
    echo json_encode(['error' => 'No student found with roll number: ' . $roll_no]);
    $stmt_check->close();
    $conn->close();
    exit;
}

$student = $result_check->fetch_assoc();
$student_id = $student['id'];
$student_name = $student['name'];
$stmt_check->close();

file_put_contents($logFile, "Student found: id=$student_id, name=$student_name\n", FILE_APPEND);

// Count holidays in the month
$sql_holiday = "SELECT COUNT(*) AS holiday_count FROM holidays WHERE date LIKE ?";
$month_pattern = $month . '%';
$stmt_holiday = $conn->prepare($sql_holiday);
$stmt_holiday->bind_param('s', $month_pattern);
$stmt_holiday->execute();
$result_holiday = $stmt_holiday->get_result();
$holiday_count = $result_holiday->fetch_assoc()['holiday_count'];
$stmt_holiday->close();

file_put_contents($logFile, "Holiday count: $holiday_count\n", FILE_APPEND);

// Calculate total days in the month (excluding holidays)
$year = substr($month, 0, 4);
$month_num = substr($month, 5, 2);
$total_days = cal_days_in_month(CAL_GREGORIAN, $month_num, $year) - $holiday_count;

// Query to fetch attendance summary for the month
$sql = "
    SELECT 
        s.name,
        s.roll_no,
        COALESCE(SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END), 0) AS present_count,
        COALESCE(SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END), 0) AS absent_count,
        COALESCE(SUM(CASE WHEN a.status = 'On Duty' THEN 1 ELSE 0 END), 0) AS onduty_count,
        COALESCE(SUM(CASE WHEN a.status = 'Holiday' THEN 1 ELSE 0 END), 0) AS attendance_holiday_count
    FROM students s
    LEFT JOIN attendance a ON s.id = a.student_id AND a.date LIKE ?
    WHERE s.roll_no = ?
    GROUP BY s.id
";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    file_put_contents($logFile, "Query preparation failed: " . $conn->error . "\n", FILE_APPEND);
    http_response_code(500);
    echo json_encode(['error' => 'Query preparation failed: ' . $conn->error]);
    $conn->close();
    exit;
}

$stmt->bind_param('ss', $month_pattern, $roll_no);
$stmt->execute();
$result = $stmt->get_result();

$summary = [];
if ($row = $result->fetch_assoc()) {
    $effective_present = $row['present_count'] + $row['onduty_count'];
    $numerator = $effective_present - $row['absent_count'];
    $percent = ($total_days > 0) ? round(($numerator / $total_days) * 100, 2) : 0.00;

    $summary = [
        'name' => $row['name'],
        'roll_no' => $row['roll_no'],
        'present_count' => (int)$row['present_count'],
        'absent_count' => (int)$row['absent_count'],
        'onduty_count' => (int)$row['onduty_count'],
        'holiday_count' => (int)$holiday_count,
        'percent' => $percent
    ];
    file_put_contents($logFile, "Summary generated: " . json_encode($summary) . "\n", FILE_APPEND);
} else {
    $summary = [
        'name' => $student_name,
        'roll_no' => $roll_no,
        'present_count' => 0,
        'absent_count' => 0,
        'onduty_count' => 0,
        'holiday_count' => (int)$holiday_count,
        'percent' => 0.00
    ];
    file_put_contents($logFile, "No attendance data, using default summary: " . json_encode($summary) . "\n", FILE_APPEND);
}

// Return data
header('Content-Type: application/json');
echo json_encode($summary);

$stmt->close();
$conn->close();
file_put_contents($logFile, "Request processed\n\n", FILE_APPEND);
?>