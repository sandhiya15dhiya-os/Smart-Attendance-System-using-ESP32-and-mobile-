<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '@989412musT');
define('DB_NAME', 'attendance_db');
?>