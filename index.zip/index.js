function getStatusIcon(status) {
    switch (status) {
        case 'Present':
            return `<span class="text-green-600 font-bold">✅ Present</span>`;
        case 'On Duty':
            return `<span class="text-yellow-500 font-bold">🟡 On Duty</span>`;
        case 'Absent':
            return `<span class="text-red-500 font-bold">❌ Absent</span>`;
        case 'Holiday':
            return `<span class="text-blue-500 font-bold">🎉 Holiday</span>`;
        default:
            return `<span class="text-gray-500">–</span>`;
    }
}

function loadAttendance() {
    const date = document.getElementById('date').value;
    const department = document.getElementById('department').value;
    const section = document.getElementById('section').value;
    const dateInput = document.getElementById('date');

    if (!date) {
        alert('Please select a date');
        return;
    }

    fetch(`check_holiday.php?date=${encodeURIComponent(date)}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to check holiday status');
            return response.json();
        })
        .then(holidayData => {
            const table = document.getElementById('attendance-table').parentElement;
            if (holidayData.isHoliday) {
                table.classList.add(holidayData.description === 'Sunday' ? 'holiday-red' : 'holiday-green');
                if (holidayData.description === 'Sunday') {
                    dateInput.classList.add('sunday');
                } else {
                    dateInput.classList.remove('sunday');
                }
            } else {
                table.classList.remove('holiday-red', 'holiday-green');
                dateInput.classList.remove('sunday');
            }
        })
        .catch(error => {
            console.error('Error checking holiday:', error);
            alert('Failed to check holiday status. Please try again.');
        });

    fetch(`get_attendance.php?date=${encodeURIComponent(date)}&department=${encodeURIComponent(department)}&section=${encodeURIComponent(section)}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to load attendance');
            return response.json();
        })
        .then(data => {
            const tableBody = document.getElementById('attendance-table');
            tableBody.innerHTML = '';

            if (data.error) {
                tableBody.innerHTML = `<tr><td colspan="8" class="no-data">${data.error}</td></tr>`;
                return;
            }
            if (data.message) {
                tableBody.innerHTML = `<tr><td colspan="8" class="no-data">${data.message}</td></tr>`;
                return;
            }

            data.forEach(row => {
                const statusIcon = getStatusIcon(row.status);
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="border px-4 py-2">${row.name}</td>
                    <td class="border px-4 py-2">${row.roll_no}</td>
                    <td class="border px-4 py-2">${row.mac_address}</td>
                    <td class="border px-4 py-2">${row.department}</td>
                    <td class="border px-4 py-2">${row.section}</td>
                    <td class="border px-4 py-2">${row.year}</td>
                    <td class="border px-4 py-2">${statusIcon}</td>
                    <td class="border px-4 py-2">
                        <button onclick="markOnDuty('${row.roll_no}', '${date}')" class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600">Mark On Duty</button>
                    </td>
                `;
                tableBody.appendChild(tr);
            });
        })
        .catch(error => {
            console.error('Error loading attendance:', error);
            const tableBody = document.getElementById('attendance-table');
            tableBody.innerHTML = `<tr><td colspan="8" class="no-data">Failed to load attendance records. Please try again.</td></tr>`;
        });
}

function markOnDuty(rollNo, date) {
    fetch('mark_onduty.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `student_id=${encodeURIComponent(rollNo)}&date=${encodeURIComponent(date)}`
    })
        .then(response => {
            if (!response.ok) throw new Error('Failed to mark On Duty');
            return response.json();
        })
        .then(data => {
            if (data.status === 'Success') {
                alert('Marked as On Duty');
                loadAttendance();
            } else {
                alert('Error: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error marking On Duty:', error);
            alert('Failed to mark On Duty. Please try again.');
        });
}

function loadMonthlySummary() {
    const rollNo = document.getElementById('rollNoSummary').value.trim();
    const month = document.getElementById('monthSummary').value;
    const tableBody = document.getElementById('summary-table');
    tableBody.innerHTML = `<tr><td colspan="7" class="no-data">Loading...</td></tr>`;

    console.log('Loading summary for rollNo:', rollNo, 'month:', month);

    if (!rollNo || !month) {
        tableBody.innerHTML = `<tr><td colspan="7" class="no-data">Please enter a roll number and select a month</td></tr>`;
        alert('Please enter a roll number and select a month');
        return;
    }

    fetch(`get_student_monthly_summary.php?roll_no=${encodeURIComponent(rollNo)}&month=${encodeURIComponent(month)}`)
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            console.log('Summary data received:', data);
            tableBody.innerHTML = '';

            if (data.error) {
                tableBody.innerHTML = `<tr><td colspan="7" class="no-data">${data.error}</td></tr>`;
                alert(data.error);
                return;
            }

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="border px-4 py-2">${data.name}</td>
                <td class="border px-4 py-2">${data.roll_no}</td>
                <td class="border px-4 py-2 text-green-600 font-bold">${data.present_count}</td>
                <td class="border px-4 py-2 text-red-500 font-bold">${data.absent_count}</td>
                <td class="border px-4 py-2 text-yellow-500 font-bold">${data.onduty_count}</td>
                <td class="border px-4 py-2 text-blue-500 font-bold">${data.holiday_count}</td>
                <td class="border px-4 py-2">${data.percent}%</td>
            `;
            tableBody.appendChild(tr);
        })
        .catch(error => {
            console.error('Error loading monthly summary:', error);
            tableBody.innerHTML = `<tr><td colspan="7" class="no-data">Failed to load monthly summary: ${error.message}</td></tr>`;
            alert('Failed to load monthly summary: ' + error.message);
        });
}

function loadStudentAttendance() {
    const rollNo = document.getElementById('rollNoSearch').value.trim();
    const tableBody = document.getElementById('student-attendance-table');
    tableBody.innerHTML = `<tr><td colspan="4" class="no-data">Loading...</td></tr>`;

    if (!rollNo) {
        tableBody.innerHTML = `<tr><td colspan="4" class="no-data">Please enter a roll number</td></tr>`;
        alert('Please enter a roll number');
        return;
    }

    fetch(`get_student_attendance.php?roll_no=${encodeURIComponent(rollNo)}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to load student attendance');
            return response.json();
        })
        .then(data => {
            tableBody.innerHTML = '';

            if (data.error) {
                tableBody.innerHTML = `<tr><td colspan="4" class="no-data">${data.error}</td></tr>`;
                alert(data.error);
                return;
            }
            if (data.message) {
                tableBody.innerHTML = `<tr><td colspan="4" class="no-data">${data.message}</td></tr>`;
                alert(data.message);
                return;
            }

            data.forEach(row => {
                const statusIcon = getStatusIcon(row.status);
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="border px-4 py-2">${row.name}</td>
                    <td class="border px-4 py-2">${row.roll_no}</td>
                    <td class="border px-4 py-2">${row.date || '–'}</td>
                    <td class="border px-4 py-2">${statusIcon}</td>
                `;
                tableBody.appendChild(tr);
            });
        })
        .catch(error => {
            console.error('Error loading student attendance:', error);
            tableBody.innerHTML = `<tr><td colspan="4" class="no-data">Failed to load student attendance: ${error.message}</td></tr>`;
            alert('Failed to load student attendance: ' + error.message);
        });
}